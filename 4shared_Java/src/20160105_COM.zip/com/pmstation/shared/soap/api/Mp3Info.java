/**
 * Mp3Info.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class Mp3Info  implements java.io.Serializable {
    private java.lang.String album;

    private java.lang.String artist;

    private int bitrate;

    private boolean empty;

    private long fileId;

    private java.lang.String genre;

    private int length;

    private float preciseLength;

    private int sampleRate;

    private java.lang.String title;

    private int track;

    private int year;

    public Mp3Info() {
    }

    public Mp3Info(
           java.lang.String album,
           java.lang.String artist,
           int bitrate,
           boolean empty,
           long fileId,
           java.lang.String genre,
           int length,
           float preciseLength,
           int sampleRate,
           java.lang.String title,
           int track,
           int year) {
           this.album = album;
           this.artist = artist;
           this.bitrate = bitrate;
           this.empty = empty;
           this.fileId = fileId;
           this.genre = genre;
           this.length = length;
           this.preciseLength = preciseLength;
           this.sampleRate = sampleRate;
           this.title = title;
           this.track = track;
           this.year = year;
    }


    /**
     * Gets the album value for this Mp3Info.
     * 
     * @return album
     */
    public java.lang.String getAlbum() {
        return album;
    }


    /**
     * Sets the album value for this Mp3Info.
     * 
     * @param album
     */
    public void setAlbum(java.lang.String album) {
        this.album = album;
    }


    /**
     * Gets the artist value for this Mp3Info.
     * 
     * @return artist
     */
    public java.lang.String getArtist() {
        return artist;
    }


    /**
     * Sets the artist value for this Mp3Info.
     * 
     * @param artist
     */
    public void setArtist(java.lang.String artist) {
        this.artist = artist;
    }


    /**
     * Gets the bitrate value for this Mp3Info.
     * 
     * @return bitrate
     */
    public int getBitrate() {
        return bitrate;
    }


    /**
     * Sets the bitrate value for this Mp3Info.
     * 
     * @param bitrate
     */
    public void setBitrate(int bitrate) {
        this.bitrate = bitrate;
    }


    /**
     * Gets the empty value for this Mp3Info.
     * 
     * @return empty
     */
    public boolean isEmpty() {
        return empty;
    }


    /**
     * Sets the empty value for this Mp3Info.
     * 
     * @param empty
     */
    public void setEmpty(boolean empty) {
        this.empty = empty;
    }


    /**
     * Gets the fileId value for this Mp3Info.
     * 
     * @return fileId
     */
    public long getFileId() {
        return fileId;
    }


    /**
     * Sets the fileId value for this Mp3Info.
     * 
     * @param fileId
     */
    public void setFileId(long fileId) {
        this.fileId = fileId;
    }


    /**
     * Gets the genre value for this Mp3Info.
     * 
     * @return genre
     */
    public java.lang.String getGenre() {
        return genre;
    }


    /**
     * Sets the genre value for this Mp3Info.
     * 
     * @param genre
     */
    public void setGenre(java.lang.String genre) {
        this.genre = genre;
    }


    /**
     * Gets the length value for this Mp3Info.
     * 
     * @return length
     */
    public int getLength() {
        return length;
    }


    /**
     * Sets the length value for this Mp3Info.
     * 
     * @param length
     */
    public void setLength(int length) {
        this.length = length;
    }


    /**
     * Gets the preciseLength value for this Mp3Info.
     * 
     * @return preciseLength
     */
    public float getPreciseLength() {
        return preciseLength;
    }


    /**
     * Sets the preciseLength value for this Mp3Info.
     * 
     * @param preciseLength
     */
    public void setPreciseLength(float preciseLength) {
        this.preciseLength = preciseLength;
    }


    /**
     * Gets the sampleRate value for this Mp3Info.
     * 
     * @return sampleRate
     */
    public int getSampleRate() {
        return sampleRate;
    }


    /**
     * Sets the sampleRate value for this Mp3Info.
     * 
     * @param sampleRate
     */
    public void setSampleRate(int sampleRate) {
        this.sampleRate = sampleRate;
    }


    /**
     * Gets the title value for this Mp3Info.
     * 
     * @return title
     */
    public java.lang.String getTitle() {
        return title;
    }


    /**
     * Sets the title value for this Mp3Info.
     * 
     * @param title
     */
    public void setTitle(java.lang.String title) {
        this.title = title;
    }


    /**
     * Gets the track value for this Mp3Info.
     * 
     * @return track
     */
    public int getTrack() {
        return track;
    }


    /**
     * Sets the track value for this Mp3Info.
     * 
     * @param track
     */
    public void setTrack(int track) {
        this.track = track;
    }


    /**
     * Gets the year value for this Mp3Info.
     * 
     * @return year
     */
    public int getYear() {
        return year;
    }


    /**
     * Sets the year value for this Mp3Info.
     * 
     * @param year
     */
    public void setYear(int year) {
        this.year = year;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Mp3Info)) return false;
        Mp3Info other = (Mp3Info) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.album==null && other.getAlbum()==null) || 
             (this.album!=null &&
              this.album.equals(other.getAlbum()))) &&
            ((this.artist==null && other.getArtist()==null) || 
             (this.artist!=null &&
              this.artist.equals(other.getArtist()))) &&
            this.bitrate == other.getBitrate() &&
            this.empty == other.isEmpty() &&
            this.fileId == other.getFileId() &&
            ((this.genre==null && other.getGenre()==null) || 
             (this.genre!=null &&
              this.genre.equals(other.getGenre()))) &&
            this.length == other.getLength() &&
            this.preciseLength == other.getPreciseLength() &&
            this.sampleRate == other.getSampleRate() &&
            ((this.title==null && other.getTitle()==null) || 
             (this.title!=null &&
              this.title.equals(other.getTitle()))) &&
            this.track == other.getTrack() &&
            this.year == other.getYear();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAlbum() != null) {
            _hashCode += getAlbum().hashCode();
        }
        if (getArtist() != null) {
            _hashCode += getArtist().hashCode();
        }
        _hashCode += getBitrate();
        _hashCode += (isEmpty() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += new Long(getFileId()).hashCode();
        if (getGenre() != null) {
            _hashCode += getGenre().hashCode();
        }
        _hashCode += getLength();
        _hashCode += new Float(getPreciseLength()).hashCode();
        _hashCode += getSampleRate();
        if (getTitle() != null) {
            _hashCode += getTitle().hashCode();
        }
        _hashCode += getTrack();
        _hashCode += getYear();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Mp3Info.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "mp3Info"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("album");
        elemField.setXmlName(new javax.xml.namespace.QName("", "album"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("artist");
        elemField.setXmlName(new javax.xml.namespace.QName("", "artist"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bitrate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bitrate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empty");
        elemField.setXmlName(new javax.xml.namespace.QName("", "empty"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fileId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genre");
        elemField.setXmlName(new javax.xml.namespace.QName("", "genre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("length");
        elemField.setXmlName(new javax.xml.namespace.QName("", "length"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("preciseLength");
        elemField.setXmlName(new javax.xml.namespace.QName("", "preciseLength"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "float"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sampleRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sampleRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("title");
        elemField.setXmlName(new javax.xml.namespace.QName("", "title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("track");
        elemField.setXmlName(new javax.xml.namespace.QName("", "track"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("year");
        elemField.setXmlName(new javax.xml.namespace.QName("", "year"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
