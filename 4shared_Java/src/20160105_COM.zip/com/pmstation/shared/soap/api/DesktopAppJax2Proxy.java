package com.pmstation.shared.soap.api;

public class DesktopAppJax2Proxy implements com.pmstation.shared.soap.api.DesktopAppJax2 {
  private String _endpoint = null;
  private com.pmstation.shared.soap.api.DesktopAppJax2 desktopAppJax2 = null;
  
  public DesktopAppJax2Proxy() {
    _initDesktopAppJax2Proxy();
  }
  
  public DesktopAppJax2Proxy(String endpoint) {
    _endpoint = endpoint;
    _initDesktopAppJax2Proxy();
  }
  
  private void _initDesktopAppJax2Proxy() {
    try {
      desktopAppJax2 = (new com.pmstation.shared.soap.api.DesktopAppJax2ServiceLocator()).getDesktopAppJax2Port();
      if (desktopAppJax2 != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)desktopAppJax2)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)desktopAppJax2)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (desktopAppJax2 != null)
      ((javax.xml.rpc.Stub)desktopAppJax2)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.pmstation.shared.soap.api.DesktopAppJax2 getDesktopAppJax2() {
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2;
  }
  
  public java.lang.String run(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.run(arg0, arg1, arg2, arg3);
  }
  
  public long getFreeSpace(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFreeSpace(arg0, arg1);
  }
  
  public long checkFile(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.checkFile(arg0, arg1, arg2);
  }
  
  public java.lang.String getPreviewLink(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getPreviewLink(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getFiles(java.lang.String arg0, java.lang.String arg1, long[] arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFiles(arg0, arg1, arg2);
  }
  
  public boolean hasRightUpload() throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.hasRightUpload();
  }
  
  public java.lang.String getPlaylistLink(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getPlaylistLink(arg0, arg1, arg2);
  }
  
  public int reportError(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.reportError(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem getRoot(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getRoot(arg0, arg1);
  }
  
  public java.lang.String login(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.login(arg0, arg1);
  }
  
  public long getMaxFileSize(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getMaxFileSize(arg0, arg1);
  }
  
  public long getSpaceLimit(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getSpaceLimit(arg0, arg1);
  }
  
  public com.pmstation.shared.soap.api.UserSettings getSettings(java.lang.String arg0, java.lang.String arg1, int arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getSettings(arg0, arg1, arg2);
  }
  
  public void markSynchronized(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.markSynchronized(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.DirHistoryDTO[] getHistory(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getHistory(arg0, arg1, arg2);
  }
  
  public boolean isVerified(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.isVerified(arg0, arg1);
  }
  
  public void deleteFile(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.deleteFile(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getAllFolders(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getAllFolders(arg0, arg1);
  }
  
  public java.lang.String signupUsernameWithName(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, java.lang.String arg3, java.lang.String arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.signupUsernameWithName(arg0, arg1, arg2, arg3, arg4);
  }
  
  public com.pmstation.shared.soap.api.UserSettings[] getAllSettings(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getAllSettings(arg0, arg1);
  }
  
  public com.pmstation.shared.soap.api.SettingsGroup[] getSettingGroups(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getSettingGroups(arg0, arg1);
  }
  
  public java.lang.String addToMyAccount(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.addToMyAccount(arg0, arg1, arg2, arg3);
  }
  
  public long addToFavorites(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.addToFavorites(arg0, arg1, arg2);
  }
  
  public long removeFromFavorites(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.removeFromFavorites(arg0, arg1, arg2);
  }
  
  public int emptyRecycleBin(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.emptyRecycleBin(arg0, arg1);
  }
  
  public com.pmstation.shared.soap.api.Mp3Info getMp3FileInfo(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getMp3FileInfo(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.Mp3Info[] getMp3FileInfos(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getMp3FileInfos(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.ExifInfo[] getExifFileInfos(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getExifFileInfos(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.ExifInfo getExifFileInfo(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getExifFileInfo(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountInfo getAccountInfo(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getAccountInfo(arg0, arg1);
  }
  
  public java.lang.String getVideoPreviewLink(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getVideoPreviewLink(arg0, arg1, arg2);
  }
  
  public java.lang.String getSmallImageLink(java.lang.String arg0, java.lang.String arg1, long arg2, int arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getSmallImageLink(arg0, arg1, arg2, arg3);
  }
  
  public java.lang.String getSharedPlaylistLink(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, java.lang.String arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getSharedPlaylistLink(arg0, arg1, arg2, arg3, arg4);
  }
  
  public java.lang.String getFileVersionLink(java.lang.String arg0, java.lang.String arg1, long arg2, int arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFileVersionLink(arg0, arg1, arg2, arg3);
  }
  
  public java.lang.String firstRun(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.firstRun(arg0, arg1);
  }
  
  public int reportErrorLog(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.reportErrorLog(arg0, arg1, arg2);
  }
  
  public long checkCreateFile(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, long arg3, byte[] arg4, long arg5) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.checkCreateFile(arg0, arg1, arg2, arg3, arg4, arg5);
  }
  
  public java.lang.String restorePassword(java.lang.String arg0) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.restorePassword(arg0);
  }
  
  public java.lang.String changePassword(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.changePassword(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] searchAccount(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, int arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.searchAccount(arg0, arg1, arg2, arg3, arg4);
  }
  
  public com.pmstation.shared.soap.api.ResumableEntity[] getResumableInfo(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getResumableInfo(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.BaseResponse verifyEmail(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.verifyEmail(arg0, arg1);
  }
  
  public java.lang.String renameFileEx(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.renameFileEx(arg0, arg1, arg2, arg3);
  }
  
  public java.lang.String renameFolderEx(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.renameFolderEx(arg0, arg1, arg2, arg3);
  }
  
  public void deleteFolders(java.lang.String arg0, java.lang.String arg1, long[] arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.deleteFolders(arg0, arg1, arg2);
  }
  
  public void restoreFolder(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.restoreFolder(arg0, arg1, arg2);
  }
  
  public void restoreFolders(java.lang.String arg0, java.lang.String arg1, long[] arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.restoreFolders(arg0, arg1, arg2);
  }
  
  public long getSharedDirSize(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getSharedDirSize(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.NotificationsTypeResponse notificationsStatus(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.notificationsStatus(arg0, arg1);
  }
  
  public java.lang.String getToolUrl(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getToolUrl(arg0, arg1);
  }
  
  public java.lang.String[] getFileDescription(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFileDescription(arg0, arg1, arg2);
  }
  
  public java.lang.String getDirDescription(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getDirDescription(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getFavorites(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFavorites(arg0, arg1);
  }
  
  public com.pmstation.shared.soap.api.FileUploadInfo simpleUploadStart(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, long arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.simpleUploadStart(arg0, arg1, arg2, arg3, arg4);
  }
  
  public java.lang.String setFileDescription(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, java.lang.String arg4, java.lang.String arg5, boolean arg6, boolean arg7) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.setFileDescription(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7);
  }
  
  public java.lang.String getToolVersion(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getToolVersion(arg0, arg1);
  }
  
  public java.lang.String checkSubdomain(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.checkSubdomain(arg0, arg1, arg2, arg3);
  }
  
  public long createNewFolder(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.createNewFolder(arg0, arg1, arg2, arg3);
  }
  
  public java.lang.String createUploadSessionKey(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.createUploadSessionKey(arg0, arg1, arg2);
  }
  
  public boolean creatNewFolder(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.creatNewFolder(arg0, arg1, arg2, arg3);
  }
  
  public long decodeLink(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.decodeLink(arg0, arg1, arg2);
  }
  
  public void deleteFileFinal(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.deleteFileFinal(arg0, arg1, arg2);
  }
  
  public void deleteFolder(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.deleteFolder(arg0, arg1, arg2);
  }
  
  public void deleteFolderFinal(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.deleteFolderFinal(arg0, arg1, arg2);
  }
  
  public void downloadFinished(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.downloadFinished(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getAllItems(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getAllItems(arg0, arg1);
  }
  
  public long getCurrentUploaderVersion() throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getCurrentUploaderVersion();
  }
  
  public java.lang.String getDirectLink(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getDirectLink(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem getDirInfo(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getDirInfo(arg0, arg1, arg2);
  }
  
  public java.lang.String getFileDownloadLink(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFileDownloadLink(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem getFileInfo(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFileInfo(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.SharedFolderProperties[] getFolderSharingProperties(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getFolderSharingProperties(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.DirHistoryDTO[][] getHistoriesFromId(java.lang.String arg0, java.lang.String arg1, long[] arg2, long[] arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getHistoriesFromId(arg0, arg1, arg2, arg3);
  }
  
  public com.pmstation.shared.soap.api.DirHistoryDTO[] getHistoryFromId(java.lang.String arg0, java.lang.String arg1, long arg2, long arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getHistoryFromId(arg0, arg1, arg2, arg3);
  }
  
  public long getHistoryLastId(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getHistoryLastId(arg0, arg1, arg2);
  }
  
  public java.lang.String setDirDescription(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, boolean arg4, boolean arg5) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.setDirDescription(arg0, arg1, arg2, arg3, arg4, arg5);
  }
  
  public java.lang.String reportAbuse(java.lang.String arg0, java.lang.String arg1, boolean arg2, java.lang.String arg3, java.lang.String arg4, java.lang.String arg5, java.lang.String arg6, java.lang.String arg7, java.lang.String arg8, java.lang.String arg9) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.reportAbuse(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
  }
  
  public java.lang.String[] checkSettings(java.lang.String arg0, java.lang.String arg1, com.pmstation.shared.soap.api.UserSettings arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.checkSettings(arg0, arg1, arg2);
  }
  
  public java.lang.String[] applySettings(java.lang.String arg0, java.lang.String arg1, com.pmstation.shared.soap.api.UserSettings arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.applySettings(arg0, arg1, arg2);
  }
  
  public int checkSharedDirAccess(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, java.lang.String arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.checkSharedDirAccess(arg0, arg1, arg2, arg3, arg4);
  }
  
  public java.lang.String decodeId(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.decodeId(arg0, arg1, arg2);
  }
  
  public java.lang.String[] getToolList() throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getToolList();
  }
  
  public com.pmstation.shared.soap.api.NotificationResponse[] notificationsList(java.lang.String arg0, java.lang.String arg1, int arg2, int arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.notificationsList(arg0, arg1, arg2, arg3);
  }
  
  public com.pmstation.shared.soap.api.NotificationResponse[] notificationsMarkAsSeen(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.notificationsMarkAsSeen(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem getItemInfo(java.lang.String arg0, java.lang.String arg1, long arg2, boolean arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getItemInfo(arg0, arg1, arg2, arg3);
  }
  
  public long getItemsCount(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getItemsCount(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getItemsPartial(java.lang.String arg0, java.lang.String arg1, long arg2, int arg3, int arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getItemsPartial(arg0, arg1, arg2, arg3, arg4);
  }
  
  public long getNewFileDataCenter(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getNewFileDataCenter(arg0, arg1);
  }
  
  public long getNotOwnedSizeLimit() throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getNotOwnedSizeLimit();
  }
  
  public com.pmstation.shared.soap.api.DirHistoryDTO[][] getNotRecursiveHistories(java.lang.String arg0, java.lang.String arg1, long[] arg2, long[] arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getNotRecursiveHistories(arg0, arg1, arg2, arg3);
  }
  
  public java.lang.String[] getOperationDescriptions() throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getOperationDescriptions();
  }
  
  public long getOwnedSizeLimit() throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getOwnedSizeLimit();
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getRecycleBinItems(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getRecycleBinItems(arg0, arg1);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getDirLinkItems(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getDirLinkItems(arg0, arg1);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getSharedDirItems(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, java.lang.String arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getSharedDirItems(arg0, arg1, arg2, arg3, arg4);
  }
  
  public java.lang.String getUploadFormUrl(int arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getUploadFormUrl(arg0, arg1);
  }
  
  public boolean isAccountActive(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.isAccountActive(arg0, arg1);
  }
  
  public boolean isAccountBanned(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.isAccountBanned(arg0, arg1);
  }
  
  public boolean isAccountPremium(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.isAccountPremium(arg0, arg1);
  }
  
  public boolean isExistsLoginPassword(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.isExistsLoginPassword(arg0, arg1);
  }
  
  public java.lang.String pasteFilesDirs(java.lang.String arg0, java.lang.String arg1, long arg2, boolean arg3, long[] arg4, long[] arg5) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.pasteFilesDirs(arg0, arg1, arg2, arg3, arg4, arg5);
  }
  
  public long renameFile(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.renameFile(arg0, arg1, arg2, arg3);
  }
  
  public long renameFolder(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.renameFolder(arg0, arg1, arg2, arg3);
  }
  
  public void restoreFile(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.restoreFile(arg0, arg1, arg2);
  }
  
  public void restoreFiles(java.lang.String arg0, java.lang.String arg1, long[] arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.restoreFiles(arg0, arg1, arg2);
  }
  
  public java.lang.String setFolderSharingProperties(java.lang.String arg0, java.lang.String arg1, long arg2, com.pmstation.shared.soap.api.SharedFolderProperties arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.setFolderSharingProperties(arg0, arg1, arg2, arg3);
  }
  
  public java.lang.String signup(java.lang.String arg0, java.lang.String arg1) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.signup(arg0, arg1);
  }
  
  public java.lang.String signupWithName(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.signupWithName(arg0, arg1, arg2, arg3);
  }
  
  public void syncFinished(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.syncFinished(arg0, arg1, arg2);
  }
  
  public void uploadCancelFile(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    desktopAppJax2.uploadCancelFile(arg0, arg1, arg2);
  }
  
  public boolean uploaderLoggedIn(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.uploaderLoggedIn(arg0, arg1, arg2, arg3);
  }
  
  public java.lang.String uploadFinishFile(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.uploadFinishFile(arg0, arg1, arg2, arg3);
  }
  
  public boolean uploadStartedFileExists(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.uploadStartedFileExists(arg0, arg1, arg2);
  }
  
  public long uploadStartFile(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, long arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.uploadStartFile(arg0, arg1, arg2, arg3, arg4);
  }
  
  public long uploadStartFileUpdate(java.lang.String arg0, java.lang.String arg1, long arg2, java.lang.String arg3, long arg4) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.uploadStartFileUpdate(arg0, arg1, arg2, arg3, arg4);
  }
  
  public java.lang.String signupUsername(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.signupUsername(arg0, arg1, arg2);
  }
  
  public com.pmstation.shared.soap.api.AccountItem[] getItems(java.lang.String arg0, java.lang.String arg1, long arg2) throws java.rmi.RemoteException{
    if (desktopAppJax2 == null)
      _initDesktopAppJax2Proxy();
    return desktopAppJax2.getItems(arg0, arg1, arg2);
  }
  
  
}