/**
 * DirHistoryDTO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class DirHistoryDTO  implements java.io.Serializable {
    private java.lang.String compId;

    private java.util.Calendar date;

    private java.lang.Long dirId;

    private java.lang.Long fileId;

    private long id;

    private int operation;

    private long parentDirId;

    private java.lang.Long sourceDirId;

    private java.lang.Long sourceFileId;

    public DirHistoryDTO() {
    }

    public DirHistoryDTO(
           java.lang.String compId,
           java.util.Calendar date,
           java.lang.Long dirId,
           java.lang.Long fileId,
           long id,
           int operation,
           long parentDirId,
           java.lang.Long sourceDirId,
           java.lang.Long sourceFileId) {
           this.compId = compId;
           this.date = date;
           this.dirId = dirId;
           this.fileId = fileId;
           this.id = id;
           this.operation = operation;
           this.parentDirId = parentDirId;
           this.sourceDirId = sourceDirId;
           this.sourceFileId = sourceFileId;
    }


    /**
     * Gets the compId value for this DirHistoryDTO.
     * 
     * @return compId
     */
    public java.lang.String getCompId() {
        return compId;
    }


    /**
     * Sets the compId value for this DirHistoryDTO.
     * 
     * @param compId
     */
    public void setCompId(java.lang.String compId) {
        this.compId = compId;
    }


    /**
     * Gets the date value for this DirHistoryDTO.
     * 
     * @return date
     */
    public java.util.Calendar getDate() {
        return date;
    }


    /**
     * Sets the date value for this DirHistoryDTO.
     * 
     * @param date
     */
    public void setDate(java.util.Calendar date) {
        this.date = date;
    }


    /**
     * Gets the dirId value for this DirHistoryDTO.
     * 
     * @return dirId
     */
    public java.lang.Long getDirId() {
        return dirId;
    }


    /**
     * Sets the dirId value for this DirHistoryDTO.
     * 
     * @param dirId
     */
    public void setDirId(java.lang.Long dirId) {
        this.dirId = dirId;
    }


    /**
     * Gets the fileId value for this DirHistoryDTO.
     * 
     * @return fileId
     */
    public java.lang.Long getFileId() {
        return fileId;
    }


    /**
     * Sets the fileId value for this DirHistoryDTO.
     * 
     * @param fileId
     */
    public void setFileId(java.lang.Long fileId) {
        this.fileId = fileId;
    }


    /**
     * Gets the id value for this DirHistoryDTO.
     * 
     * @return id
     */
    public long getId() {
        return id;
    }


    /**
     * Sets the id value for this DirHistoryDTO.
     * 
     * @param id
     */
    public void setId(long id) {
        this.id = id;
    }


    /**
     * Gets the operation value for this DirHistoryDTO.
     * 
     * @return operation
     */
    public int getOperation() {
        return operation;
    }


    /**
     * Sets the operation value for this DirHistoryDTO.
     * 
     * @param operation
     */
    public void setOperation(int operation) {
        this.operation = operation;
    }


    /**
     * Gets the parentDirId value for this DirHistoryDTO.
     * 
     * @return parentDirId
     */
    public long getParentDirId() {
        return parentDirId;
    }


    /**
     * Sets the parentDirId value for this DirHistoryDTO.
     * 
     * @param parentDirId
     */
    public void setParentDirId(long parentDirId) {
        this.parentDirId = parentDirId;
    }


    /**
     * Gets the sourceDirId value for this DirHistoryDTO.
     * 
     * @return sourceDirId
     */
    public java.lang.Long getSourceDirId() {
        return sourceDirId;
    }


    /**
     * Sets the sourceDirId value for this DirHistoryDTO.
     * 
     * @param sourceDirId
     */
    public void setSourceDirId(java.lang.Long sourceDirId) {
        this.sourceDirId = sourceDirId;
    }


    /**
     * Gets the sourceFileId value for this DirHistoryDTO.
     * 
     * @return sourceFileId
     */
    public java.lang.Long getSourceFileId() {
        return sourceFileId;
    }


    /**
     * Sets the sourceFileId value for this DirHistoryDTO.
     * 
     * @param sourceFileId
     */
    public void setSourceFileId(java.lang.Long sourceFileId) {
        this.sourceFileId = sourceFileId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DirHistoryDTO)) return false;
        DirHistoryDTO other = (DirHistoryDTO) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.compId==null && other.getCompId()==null) || 
             (this.compId!=null &&
              this.compId.equals(other.getCompId()))) &&
            ((this.date==null && other.getDate()==null) || 
             (this.date!=null &&
              this.date.equals(other.getDate()))) &&
            ((this.dirId==null && other.getDirId()==null) || 
             (this.dirId!=null &&
              this.dirId.equals(other.getDirId()))) &&
            ((this.fileId==null && other.getFileId()==null) || 
             (this.fileId!=null &&
              this.fileId.equals(other.getFileId()))) &&
            this.id == other.getId() &&
            this.operation == other.getOperation() &&
            this.parentDirId == other.getParentDirId() &&
            ((this.sourceDirId==null && other.getSourceDirId()==null) || 
             (this.sourceDirId!=null &&
              this.sourceDirId.equals(other.getSourceDirId()))) &&
            ((this.sourceFileId==null && other.getSourceFileId()==null) || 
             (this.sourceFileId!=null &&
              this.sourceFileId.equals(other.getSourceFileId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCompId() != null) {
            _hashCode += getCompId().hashCode();
        }
        if (getDate() != null) {
            _hashCode += getDate().hashCode();
        }
        if (getDirId() != null) {
            _hashCode += getDirId().hashCode();
        }
        if (getFileId() != null) {
            _hashCode += getFileId().hashCode();
        }
        _hashCode += new Long(getId()).hashCode();
        _hashCode += getOperation();
        _hashCode += new Long(getParentDirId()).hashCode();
        if (getSourceDirId() != null) {
            _hashCode += getSourceDirId().hashCode();
        }
        if (getSourceFileId() != null) {
            _hashCode += getSourceFileId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DirHistoryDTO.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "dirHistoryDTO"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "compId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dirId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dirId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fileId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "operation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentDirId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "parentDirId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceDirId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sourceDirId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceFileId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sourceFileId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
