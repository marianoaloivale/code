/**
 * NotificationsTypeResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class NotificationsTypeResponse  implements java.io.Serializable {
    private com.pmstation.shared.soap.api.NotificationsStatusResponse shareFile;

    private com.pmstation.shared.soap.api.NotificationsStatusResponse shareFolder;

    private com.pmstation.shared.soap.api.NotificationsStatusResponse comment;

    public NotificationsTypeResponse() {
    }

    public NotificationsTypeResponse(
           com.pmstation.shared.soap.api.NotificationsStatusResponse shareFile,
           com.pmstation.shared.soap.api.NotificationsStatusResponse shareFolder,
           com.pmstation.shared.soap.api.NotificationsStatusResponse comment) {
           this.shareFile = shareFile;
           this.shareFolder = shareFolder;
           this.comment = comment;
    }


    /**
     * Gets the shareFile value for this NotificationsTypeResponse.
     * 
     * @return shareFile
     */
    public com.pmstation.shared.soap.api.NotificationsStatusResponse getShareFile() {
        return shareFile;
    }


    /**
     * Sets the shareFile value for this NotificationsTypeResponse.
     * 
     * @param shareFile
     */
    public void setShareFile(com.pmstation.shared.soap.api.NotificationsStatusResponse shareFile) {
        this.shareFile = shareFile;
    }


    /**
     * Gets the shareFolder value for this NotificationsTypeResponse.
     * 
     * @return shareFolder
     */
    public com.pmstation.shared.soap.api.NotificationsStatusResponse getShareFolder() {
        return shareFolder;
    }


    /**
     * Sets the shareFolder value for this NotificationsTypeResponse.
     * 
     * @param shareFolder
     */
    public void setShareFolder(com.pmstation.shared.soap.api.NotificationsStatusResponse shareFolder) {
        this.shareFolder = shareFolder;
    }


    /**
     * Gets the comment value for this NotificationsTypeResponse.
     * 
     * @return comment
     */
    public com.pmstation.shared.soap.api.NotificationsStatusResponse getComment() {
        return comment;
    }


    /**
     * Sets the comment value for this NotificationsTypeResponse.
     * 
     * @param comment
     */
    public void setComment(com.pmstation.shared.soap.api.NotificationsStatusResponse comment) {
        this.comment = comment;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NotificationsTypeResponse)) return false;
        NotificationsTypeResponse other = (NotificationsTypeResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.shareFile==null && other.getShareFile()==null) || 
             (this.shareFile!=null &&
              this.shareFile.equals(other.getShareFile()))) &&
            ((this.shareFolder==null && other.getShareFolder()==null) || 
             (this.shareFolder!=null &&
              this.shareFolder.equals(other.getShareFolder()))) &&
            ((this.comment==null && other.getComment()==null) || 
             (this.comment!=null &&
              this.comment.equals(other.getComment())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getShareFile() != null) {
            _hashCode += getShareFile().hashCode();
        }
        if (getShareFolder() != null) {
            _hashCode += getShareFolder().hashCode();
        }
        if (getComment() != null) {
            _hashCode += getComment().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NotificationsTypeResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "notificationsTypeResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shareFile");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shareFile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "notificationsStatusResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shareFolder");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shareFolder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "notificationsStatusResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comment");
        elemField.setXmlName(new javax.xml.namespace.QName("", "comment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "notificationsStatusResponse"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
