/**
 * SharedFolderProperties.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class SharedFolderProperties  implements java.io.Serializable {
    private boolean createSubFolders;

    private boolean delete;

    private boolean disableAnonimUpload;

    private boolean emailOnUpload;

    private boolean embed;

    private boolean fileProperties;

    private boolean moderator;

    private boolean onlyPublic;

    private java.lang.String password;

    private boolean publicSearch;

    private boolean search;

    private boolean shared;

    private int sharedMode;

    private boolean subdomainAllowed;

    private java.lang.String subdomainName;

    private boolean thumbNailOn;

    private boolean updateFiles;

    private boolean upload;

    private boolean viewModeDetails;

    private boolean viewSubfolders;

    private boolean webGrab;

    public SharedFolderProperties() {
    }

    public SharedFolderProperties(
           boolean createSubFolders,
           boolean delete,
           boolean disableAnonimUpload,
           boolean emailOnUpload,
           boolean embed,
           boolean fileProperties,
           boolean moderator,
           boolean onlyPublic,
           java.lang.String password,
           boolean publicSearch,
           boolean search,
           boolean shared,
           int sharedMode,
           boolean subdomainAllowed,
           java.lang.String subdomainName,
           boolean thumbNailOn,
           boolean updateFiles,
           boolean upload,
           boolean viewModeDetails,
           boolean viewSubfolders,
           boolean webGrab) {
           this.createSubFolders = createSubFolders;
           this.delete = delete;
           this.disableAnonimUpload = disableAnonimUpload;
           this.emailOnUpload = emailOnUpload;
           this.embed = embed;
           this.fileProperties = fileProperties;
           this.moderator = moderator;
           this.onlyPublic = onlyPublic;
           this.password = password;
           this.publicSearch = publicSearch;
           this.search = search;
           this.shared = shared;
           this.sharedMode = sharedMode;
           this.subdomainAllowed = subdomainAllowed;
           this.subdomainName = subdomainName;
           this.thumbNailOn = thumbNailOn;
           this.updateFiles = updateFiles;
           this.upload = upload;
           this.viewModeDetails = viewModeDetails;
           this.viewSubfolders = viewSubfolders;
           this.webGrab = webGrab;
    }


    /**
     * Gets the createSubFolders value for this SharedFolderProperties.
     * 
     * @return createSubFolders
     */
    public boolean isCreateSubFolders() {
        return createSubFolders;
    }


    /**
     * Sets the createSubFolders value for this SharedFolderProperties.
     * 
     * @param createSubFolders
     */
    public void setCreateSubFolders(boolean createSubFolders) {
        this.createSubFolders = createSubFolders;
    }


    /**
     * Gets the delete value for this SharedFolderProperties.
     * 
     * @return delete
     */
    public boolean isDelete() {
        return delete;
    }


    /**
     * Sets the delete value for this SharedFolderProperties.
     * 
     * @param delete
     */
    public void setDelete(boolean delete) {
        this.delete = delete;
    }


    /**
     * Gets the disableAnonimUpload value for this SharedFolderProperties.
     * 
     * @return disableAnonimUpload
     */
    public boolean isDisableAnonimUpload() {
        return disableAnonimUpload;
    }


    /**
     * Sets the disableAnonimUpload value for this SharedFolderProperties.
     * 
     * @param disableAnonimUpload
     */
    public void setDisableAnonimUpload(boolean disableAnonimUpload) {
        this.disableAnonimUpload = disableAnonimUpload;
    }


    /**
     * Gets the emailOnUpload value for this SharedFolderProperties.
     * 
     * @return emailOnUpload
     */
    public boolean isEmailOnUpload() {
        return emailOnUpload;
    }


    /**
     * Sets the emailOnUpload value for this SharedFolderProperties.
     * 
     * @param emailOnUpload
     */
    public void setEmailOnUpload(boolean emailOnUpload) {
        this.emailOnUpload = emailOnUpload;
    }


    /**
     * Gets the embed value for this SharedFolderProperties.
     * 
     * @return embed
     */
    public boolean isEmbed() {
        return embed;
    }


    /**
     * Sets the embed value for this SharedFolderProperties.
     * 
     * @param embed
     */
    public void setEmbed(boolean embed) {
        this.embed = embed;
    }


    /**
     * Gets the fileProperties value for this SharedFolderProperties.
     * 
     * @return fileProperties
     */
    public boolean isFileProperties() {
        return fileProperties;
    }


    /**
     * Sets the fileProperties value for this SharedFolderProperties.
     * 
     * @param fileProperties
     */
    public void setFileProperties(boolean fileProperties) {
        this.fileProperties = fileProperties;
    }


    /**
     * Gets the moderator value for this SharedFolderProperties.
     * 
     * @return moderator
     */
    public boolean isModerator() {
        return moderator;
    }


    /**
     * Sets the moderator value for this SharedFolderProperties.
     * 
     * @param moderator
     */
    public void setModerator(boolean moderator) {
        this.moderator = moderator;
    }


    /**
     * Gets the onlyPublic value for this SharedFolderProperties.
     * 
     * @return onlyPublic
     */
    public boolean isOnlyPublic() {
        return onlyPublic;
    }


    /**
     * Sets the onlyPublic value for this SharedFolderProperties.
     * 
     * @param onlyPublic
     */
    public void setOnlyPublic(boolean onlyPublic) {
        this.onlyPublic = onlyPublic;
    }


    /**
     * Gets the password value for this SharedFolderProperties.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this SharedFolderProperties.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the publicSearch value for this SharedFolderProperties.
     * 
     * @return publicSearch
     */
    public boolean isPublicSearch() {
        return publicSearch;
    }


    /**
     * Sets the publicSearch value for this SharedFolderProperties.
     * 
     * @param publicSearch
     */
    public void setPublicSearch(boolean publicSearch) {
        this.publicSearch = publicSearch;
    }


    /**
     * Gets the search value for this SharedFolderProperties.
     * 
     * @return search
     */
    public boolean isSearch() {
        return search;
    }


    /**
     * Sets the search value for this SharedFolderProperties.
     * 
     * @param search
     */
    public void setSearch(boolean search) {
        this.search = search;
    }


    /**
     * Gets the shared value for this SharedFolderProperties.
     * 
     * @return shared
     */
    public boolean isShared() {
        return shared;
    }


    /**
     * Sets the shared value for this SharedFolderProperties.
     * 
     * @param shared
     */
    public void setShared(boolean shared) {
        this.shared = shared;
    }


    /**
     * Gets the sharedMode value for this SharedFolderProperties.
     * 
     * @return sharedMode
     */
    public int getSharedMode() {
        return sharedMode;
    }


    /**
     * Sets the sharedMode value for this SharedFolderProperties.
     * 
     * @param sharedMode
     */
    public void setSharedMode(int sharedMode) {
        this.sharedMode = sharedMode;
    }


    /**
     * Gets the subdomainAllowed value for this SharedFolderProperties.
     * 
     * @return subdomainAllowed
     */
    public boolean isSubdomainAllowed() {
        return subdomainAllowed;
    }


    /**
     * Sets the subdomainAllowed value for this SharedFolderProperties.
     * 
     * @param subdomainAllowed
     */
    public void setSubdomainAllowed(boolean subdomainAllowed) {
        this.subdomainAllowed = subdomainAllowed;
    }


    /**
     * Gets the subdomainName value for this SharedFolderProperties.
     * 
     * @return subdomainName
     */
    public java.lang.String getSubdomainName() {
        return subdomainName;
    }


    /**
     * Sets the subdomainName value for this SharedFolderProperties.
     * 
     * @param subdomainName
     */
    public void setSubdomainName(java.lang.String subdomainName) {
        this.subdomainName = subdomainName;
    }


    /**
     * Gets the thumbNailOn value for this SharedFolderProperties.
     * 
     * @return thumbNailOn
     */
    public boolean isThumbNailOn() {
        return thumbNailOn;
    }


    /**
     * Sets the thumbNailOn value for this SharedFolderProperties.
     * 
     * @param thumbNailOn
     */
    public void setThumbNailOn(boolean thumbNailOn) {
        this.thumbNailOn = thumbNailOn;
    }


    /**
     * Gets the updateFiles value for this SharedFolderProperties.
     * 
     * @return updateFiles
     */
    public boolean isUpdateFiles() {
        return updateFiles;
    }


    /**
     * Sets the updateFiles value for this SharedFolderProperties.
     * 
     * @param updateFiles
     */
    public void setUpdateFiles(boolean updateFiles) {
        this.updateFiles = updateFiles;
    }


    /**
     * Gets the upload value for this SharedFolderProperties.
     * 
     * @return upload
     */
    public boolean isUpload() {
        return upload;
    }


    /**
     * Sets the upload value for this SharedFolderProperties.
     * 
     * @param upload
     */
    public void setUpload(boolean upload) {
        this.upload = upload;
    }


    /**
     * Gets the viewModeDetails value for this SharedFolderProperties.
     * 
     * @return viewModeDetails
     */
    public boolean isViewModeDetails() {
        return viewModeDetails;
    }


    /**
     * Sets the viewModeDetails value for this SharedFolderProperties.
     * 
     * @param viewModeDetails
     */
    public void setViewModeDetails(boolean viewModeDetails) {
        this.viewModeDetails = viewModeDetails;
    }


    /**
     * Gets the viewSubfolders value for this SharedFolderProperties.
     * 
     * @return viewSubfolders
     */
    public boolean isViewSubfolders() {
        return viewSubfolders;
    }


    /**
     * Sets the viewSubfolders value for this SharedFolderProperties.
     * 
     * @param viewSubfolders
     */
    public void setViewSubfolders(boolean viewSubfolders) {
        this.viewSubfolders = viewSubfolders;
    }


    /**
     * Gets the webGrab value for this SharedFolderProperties.
     * 
     * @return webGrab
     */
    public boolean isWebGrab() {
        return webGrab;
    }


    /**
     * Sets the webGrab value for this SharedFolderProperties.
     * 
     * @param webGrab
     */
    public void setWebGrab(boolean webGrab) {
        this.webGrab = webGrab;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SharedFolderProperties)) return false;
        SharedFolderProperties other = (SharedFolderProperties) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.createSubFolders == other.isCreateSubFolders() &&
            this.delete == other.isDelete() &&
            this.disableAnonimUpload == other.isDisableAnonimUpload() &&
            this.emailOnUpload == other.isEmailOnUpload() &&
            this.embed == other.isEmbed() &&
            this.fileProperties == other.isFileProperties() &&
            this.moderator == other.isModerator() &&
            this.onlyPublic == other.isOnlyPublic() &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            this.publicSearch == other.isPublicSearch() &&
            this.search == other.isSearch() &&
            this.shared == other.isShared() &&
            this.sharedMode == other.getSharedMode() &&
            this.subdomainAllowed == other.isSubdomainAllowed() &&
            ((this.subdomainName==null && other.getSubdomainName()==null) || 
             (this.subdomainName!=null &&
              this.subdomainName.equals(other.getSubdomainName()))) &&
            this.thumbNailOn == other.isThumbNailOn() &&
            this.updateFiles == other.isUpdateFiles() &&
            this.upload == other.isUpload() &&
            this.viewModeDetails == other.isViewModeDetails() &&
            this.viewSubfolders == other.isViewSubfolders() &&
            this.webGrab == other.isWebGrab();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isCreateSubFolders() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isDelete() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isDisableAnonimUpload() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isEmailOnUpload() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isEmbed() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isFileProperties() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isModerator() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isOnlyPublic() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        _hashCode += (isPublicSearch() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isSearch() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isShared() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getSharedMode();
        _hashCode += (isSubdomainAllowed() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getSubdomainName() != null) {
            _hashCode += getSubdomainName().hashCode();
        }
        _hashCode += (isThumbNailOn() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUpdateFiles() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUpload() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isViewModeDetails() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isViewSubfolders() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isWebGrab() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SharedFolderProperties.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "sharedFolderProperties"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createSubFolders");
        elemField.setXmlName(new javax.xml.namespace.QName("", "createSubFolders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("delete");
        elemField.setXmlName(new javax.xml.namespace.QName("", "delete"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("disableAnonimUpload");
        elemField.setXmlName(new javax.xml.namespace.QName("", "disableAnonimUpload"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailOnUpload");
        elemField.setXmlName(new javax.xml.namespace.QName("", "emailOnUpload"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("embed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "embed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileProperties");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fileProperties"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moderator");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moderator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("onlyPublic");
        elemField.setXmlName(new javax.xml.namespace.QName("", "onlyPublic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("", "password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publicSearch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "publicSearch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("search");
        elemField.setXmlName(new javax.xml.namespace.QName("", "search"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shared");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shared"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sharedMode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sharedMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subdomainAllowed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subdomainAllowed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subdomainName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subdomainName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thumbNailOn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "thumbNailOn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("updateFiles");
        elemField.setXmlName(new javax.xml.namespace.QName("", "updateFiles"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("upload");
        elemField.setXmlName(new javax.xml.namespace.QName("", "upload"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("viewModeDetails");
        elemField.setXmlName(new javax.xml.namespace.QName("", "viewModeDetails"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("viewSubfolders");
        elemField.setXmlName(new javax.xml.namespace.QName("", "viewSubfolders"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webGrab");
        elemField.setXmlName(new javax.xml.namespace.QName("", "webGrab"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
