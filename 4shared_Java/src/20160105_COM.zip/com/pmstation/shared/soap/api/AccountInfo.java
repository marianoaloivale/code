/**
 * AccountInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class AccountInfo  implements java.io.Serializable {
    private boolean accountPremium;

    private int accountType;

    private boolean activeUser;

    private boolean banUser;

    private java.lang.String email;

    private java.util.Calendar expirationDate;

    private long freeSpace;

    private java.util.Calendar lastLogin;

    private boolean lockUser;

    private long maxFileSize;

    private java.lang.String name;

    private long notOwnedSizeLimit;

    private long ownedSizeLimit;

    private long spaceLimit;

    private boolean syncUser;

    private boolean verified;

    public AccountInfo() {
    }

    public AccountInfo(
           boolean accountPremium,
           int accountType,
           boolean activeUser,
           boolean banUser,
           java.lang.String email,
           java.util.Calendar expirationDate,
           long freeSpace,
           java.util.Calendar lastLogin,
           boolean lockUser,
           long maxFileSize,
           java.lang.String name,
           long notOwnedSizeLimit,
           long ownedSizeLimit,
           long spaceLimit,
           boolean syncUser,
           boolean verified) {
           this.accountPremium = accountPremium;
           this.accountType = accountType;
           this.activeUser = activeUser;
           this.banUser = banUser;
           this.email = email;
           this.expirationDate = expirationDate;
           this.freeSpace = freeSpace;
           this.lastLogin = lastLogin;
           this.lockUser = lockUser;
           this.maxFileSize = maxFileSize;
           this.name = name;
           this.notOwnedSizeLimit = notOwnedSizeLimit;
           this.ownedSizeLimit = ownedSizeLimit;
           this.spaceLimit = spaceLimit;
           this.syncUser = syncUser;
           this.verified = verified;
    }


    /**
     * Gets the accountPremium value for this AccountInfo.
     * 
     * @return accountPremium
     */
    public boolean isAccountPremium() {
        return accountPremium;
    }


    /**
     * Sets the accountPremium value for this AccountInfo.
     * 
     * @param accountPremium
     */
    public void setAccountPremium(boolean accountPremium) {
        this.accountPremium = accountPremium;
    }


    /**
     * Gets the accountType value for this AccountInfo.
     * 
     * @return accountType
     */
    public int getAccountType() {
        return accountType;
    }


    /**
     * Sets the accountType value for this AccountInfo.
     * 
     * @param accountType
     */
    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }


    /**
     * Gets the activeUser value for this AccountInfo.
     * 
     * @return activeUser
     */
    public boolean isActiveUser() {
        return activeUser;
    }


    /**
     * Sets the activeUser value for this AccountInfo.
     * 
     * @param activeUser
     */
    public void setActiveUser(boolean activeUser) {
        this.activeUser = activeUser;
    }


    /**
     * Gets the banUser value for this AccountInfo.
     * 
     * @return banUser
     */
    public boolean isBanUser() {
        return banUser;
    }


    /**
     * Sets the banUser value for this AccountInfo.
     * 
     * @param banUser
     */
    public void setBanUser(boolean banUser) {
        this.banUser = banUser;
    }


    /**
     * Gets the email value for this AccountInfo.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this AccountInfo.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the expirationDate value for this AccountInfo.
     * 
     * @return expirationDate
     */
    public java.util.Calendar getExpirationDate() {
        return expirationDate;
    }


    /**
     * Sets the expirationDate value for this AccountInfo.
     * 
     * @param expirationDate
     */
    public void setExpirationDate(java.util.Calendar expirationDate) {
        this.expirationDate = expirationDate;
    }


    /**
     * Gets the freeSpace value for this AccountInfo.
     * 
     * @return freeSpace
     */
    public long getFreeSpace() {
        return freeSpace;
    }


    /**
     * Sets the freeSpace value for this AccountInfo.
     * 
     * @param freeSpace
     */
    public void setFreeSpace(long freeSpace) {
        this.freeSpace = freeSpace;
    }


    /**
     * Gets the lastLogin value for this AccountInfo.
     * 
     * @return lastLogin
     */
    public java.util.Calendar getLastLogin() {
        return lastLogin;
    }


    /**
     * Sets the lastLogin value for this AccountInfo.
     * 
     * @param lastLogin
     */
    public void setLastLogin(java.util.Calendar lastLogin) {
        this.lastLogin = lastLogin;
    }


    /**
     * Gets the lockUser value for this AccountInfo.
     * 
     * @return lockUser
     */
    public boolean isLockUser() {
        return lockUser;
    }


    /**
     * Sets the lockUser value for this AccountInfo.
     * 
     * @param lockUser
     */
    public void setLockUser(boolean lockUser) {
        this.lockUser = lockUser;
    }


    /**
     * Gets the maxFileSize value for this AccountInfo.
     * 
     * @return maxFileSize
     */
    public long getMaxFileSize() {
        return maxFileSize;
    }


    /**
     * Sets the maxFileSize value for this AccountInfo.
     * 
     * @param maxFileSize
     */
    public void setMaxFileSize(long maxFileSize) {
        this.maxFileSize = maxFileSize;
    }


    /**
     * Gets the name value for this AccountInfo.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this AccountInfo.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notOwnedSizeLimit value for this AccountInfo.
     * 
     * @return notOwnedSizeLimit
     */
    public long getNotOwnedSizeLimit() {
        return notOwnedSizeLimit;
    }


    /**
     * Sets the notOwnedSizeLimit value for this AccountInfo.
     * 
     * @param notOwnedSizeLimit
     */
    public void setNotOwnedSizeLimit(long notOwnedSizeLimit) {
        this.notOwnedSizeLimit = notOwnedSizeLimit;
    }


    /**
     * Gets the ownedSizeLimit value for this AccountInfo.
     * 
     * @return ownedSizeLimit
     */
    public long getOwnedSizeLimit() {
        return ownedSizeLimit;
    }


    /**
     * Sets the ownedSizeLimit value for this AccountInfo.
     * 
     * @param ownedSizeLimit
     */
    public void setOwnedSizeLimit(long ownedSizeLimit) {
        this.ownedSizeLimit = ownedSizeLimit;
    }


    /**
     * Gets the spaceLimit value for this AccountInfo.
     * 
     * @return spaceLimit
     */
    public long getSpaceLimit() {
        return spaceLimit;
    }


    /**
     * Sets the spaceLimit value for this AccountInfo.
     * 
     * @param spaceLimit
     */
    public void setSpaceLimit(long spaceLimit) {
        this.spaceLimit = spaceLimit;
    }


    /**
     * Gets the syncUser value for this AccountInfo.
     * 
     * @return syncUser
     */
    public boolean isSyncUser() {
        return syncUser;
    }


    /**
     * Sets the syncUser value for this AccountInfo.
     * 
     * @param syncUser
     */
    public void setSyncUser(boolean syncUser) {
        this.syncUser = syncUser;
    }


    /**
     * Gets the verified value for this AccountInfo.
     * 
     * @return verified
     */
    public boolean isVerified() {
        return verified;
    }


    /**
     * Sets the verified value for this AccountInfo.
     * 
     * @param verified
     */
    public void setVerified(boolean verified) {
        this.verified = verified;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AccountInfo)) return false;
        AccountInfo other = (AccountInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.accountPremium == other.isAccountPremium() &&
            this.accountType == other.getAccountType() &&
            this.activeUser == other.isActiveUser() &&
            this.banUser == other.isBanUser() &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.expirationDate==null && other.getExpirationDate()==null) || 
             (this.expirationDate!=null &&
              this.expirationDate.equals(other.getExpirationDate()))) &&
            this.freeSpace == other.getFreeSpace() &&
            ((this.lastLogin==null && other.getLastLogin()==null) || 
             (this.lastLogin!=null &&
              this.lastLogin.equals(other.getLastLogin()))) &&
            this.lockUser == other.isLockUser() &&
            this.maxFileSize == other.getMaxFileSize() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            this.notOwnedSizeLimit == other.getNotOwnedSizeLimit() &&
            this.ownedSizeLimit == other.getOwnedSizeLimit() &&
            this.spaceLimit == other.getSpaceLimit() &&
            this.syncUser == other.isSyncUser() &&
            this.verified == other.isVerified();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isAccountPremium() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getAccountType();
        _hashCode += (isActiveUser() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isBanUser() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getExpirationDate() != null) {
            _hashCode += getExpirationDate().hashCode();
        }
        _hashCode += new Long(getFreeSpace()).hashCode();
        if (getLastLogin() != null) {
            _hashCode += getLastLogin().hashCode();
        }
        _hashCode += (isLockUser() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += new Long(getMaxFileSize()).hashCode();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        _hashCode += new Long(getNotOwnedSizeLimit()).hashCode();
        _hashCode += new Long(getOwnedSizeLimit()).hashCode();
        _hashCode += new Long(getSpaceLimit()).hashCode();
        _hashCode += (isSyncUser() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isVerified() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AccountInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "accountInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountPremium");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accountPremium"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "accountType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activeUser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "activeUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("banUser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "banUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("", "email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expirationDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expirationDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("freeSpace");
        elemField.setXmlName(new javax.xml.namespace.QName("", "freeSpace"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastLogin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lastLogin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lockUser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lockUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxFileSize");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxFileSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notOwnedSizeLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "notOwnedSizeLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownedSizeLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ownedSizeLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("spaceLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "spaceLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("syncUser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "syncUser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verified");
        elemField.setXmlName(new javax.xml.namespace.QName("", "verified"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
