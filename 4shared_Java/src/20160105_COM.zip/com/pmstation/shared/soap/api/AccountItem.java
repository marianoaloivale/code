/**
 * AccountItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class AccountItem  implements java.io.Serializable {
    private java.util.Calendar date;

    private boolean directory;

    private int downloadCount;

    private java.lang.String downloadLink;

    private boolean empty;

    private long id;

    private boolean incomplete;

    private java.lang.String md5;

    private java.lang.String name;

    private long parentId;

    private boolean removed;

    private boolean shared;

    private long size;

    private java.lang.String smallImageLink;

    private int version;

    private java.lang.String virusScanResult;

    public AccountItem() {
    }

    public AccountItem(
           java.util.Calendar date,
           boolean directory,
           int downloadCount,
           java.lang.String downloadLink,
           boolean empty,
           long id,
           boolean incomplete,
           java.lang.String md5,
           java.lang.String name,
           long parentId,
           boolean removed,
           boolean shared,
           long size,
           java.lang.String smallImageLink,
           int version,
           java.lang.String virusScanResult) {
           this.date = date;
           this.directory = directory;
           this.downloadCount = downloadCount;
           this.downloadLink = downloadLink;
           this.empty = empty;
           this.id = id;
           this.incomplete = incomplete;
           this.md5 = md5;
           this.name = name;
           this.parentId = parentId;
           this.removed = removed;
           this.shared = shared;
           this.size = size;
           this.smallImageLink = smallImageLink;
           this.version = version;
           this.virusScanResult = virusScanResult;
    }


    /**
     * Gets the date value for this AccountItem.
     * 
     * @return date
     */
    public java.util.Calendar getDate() {
        return date;
    }


    /**
     * Sets the date value for this AccountItem.
     * 
     * @param date
     */
    public void setDate(java.util.Calendar date) {
        this.date = date;
    }


    /**
     * Gets the directory value for this AccountItem.
     * 
     * @return directory
     */
    public boolean isDirectory() {
        return directory;
    }


    /**
     * Sets the directory value for this AccountItem.
     * 
     * @param directory
     */
    public void setDirectory(boolean directory) {
        this.directory = directory;
    }


    /**
     * Gets the downloadCount value for this AccountItem.
     * 
     * @return downloadCount
     */
    public int getDownloadCount() {
        return downloadCount;
    }


    /**
     * Sets the downloadCount value for this AccountItem.
     * 
     * @param downloadCount
     */
    public void setDownloadCount(int downloadCount) {
        this.downloadCount = downloadCount;
    }


    /**
     * Gets the downloadLink value for this AccountItem.
     * 
     * @return downloadLink
     */
    public java.lang.String getDownloadLink() {
        return downloadLink;
    }


    /**
     * Sets the downloadLink value for this AccountItem.
     * 
     * @param downloadLink
     */
    public void setDownloadLink(java.lang.String downloadLink) {
        this.downloadLink = downloadLink;
    }


    /**
     * Gets the empty value for this AccountItem.
     * 
     * @return empty
     */
    public boolean isEmpty() {
        return empty;
    }


    /**
     * Sets the empty value for this AccountItem.
     * 
     * @param empty
     */
    public void setEmpty(boolean empty) {
        this.empty = empty;
    }


    /**
     * Gets the id value for this AccountItem.
     * 
     * @return id
     */
    public long getId() {
        return id;
    }


    /**
     * Sets the id value for this AccountItem.
     * 
     * @param id
     */
    public void setId(long id) {
        this.id = id;
    }


    /**
     * Gets the incomplete value for this AccountItem.
     * 
     * @return incomplete
     */
    public boolean isIncomplete() {
        return incomplete;
    }


    /**
     * Sets the incomplete value for this AccountItem.
     * 
     * @param incomplete
     */
    public void setIncomplete(boolean incomplete) {
        this.incomplete = incomplete;
    }


    /**
     * Gets the md5 value for this AccountItem.
     * 
     * @return md5
     */
    public java.lang.String getMd5() {
        return md5;
    }


    /**
     * Sets the md5 value for this AccountItem.
     * 
     * @param md5
     */
    public void setMd5(java.lang.String md5) {
        this.md5 = md5;
    }


    /**
     * Gets the name value for this AccountItem.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this AccountItem.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the parentId value for this AccountItem.
     * 
     * @return parentId
     */
    public long getParentId() {
        return parentId;
    }


    /**
     * Sets the parentId value for this AccountItem.
     * 
     * @param parentId
     */
    public void setParentId(long parentId) {
        this.parentId = parentId;
    }


    /**
     * Gets the removed value for this AccountItem.
     * 
     * @return removed
     */
    public boolean isRemoved() {
        return removed;
    }


    /**
     * Sets the removed value for this AccountItem.
     * 
     * @param removed
     */
    public void setRemoved(boolean removed) {
        this.removed = removed;
    }


    /**
     * Gets the shared value for this AccountItem.
     * 
     * @return shared
     */
    public boolean isShared() {
        return shared;
    }


    /**
     * Sets the shared value for this AccountItem.
     * 
     * @param shared
     */
    public void setShared(boolean shared) {
        this.shared = shared;
    }


    /**
     * Gets the size value for this AccountItem.
     * 
     * @return size
     */
    public long getSize() {
        return size;
    }


    /**
     * Sets the size value for this AccountItem.
     * 
     * @param size
     */
    public void setSize(long size) {
        this.size = size;
    }


    /**
     * Gets the smallImageLink value for this AccountItem.
     * 
     * @return smallImageLink
     */
    public java.lang.String getSmallImageLink() {
        return smallImageLink;
    }


    /**
     * Sets the smallImageLink value for this AccountItem.
     * 
     * @param smallImageLink
     */
    public void setSmallImageLink(java.lang.String smallImageLink) {
        this.smallImageLink = smallImageLink;
    }


    /**
     * Gets the version value for this AccountItem.
     * 
     * @return version
     */
    public int getVersion() {
        return version;
    }


    /**
     * Sets the version value for this AccountItem.
     * 
     * @param version
     */
    public void setVersion(int version) {
        this.version = version;
    }


    /**
     * Gets the virusScanResult value for this AccountItem.
     * 
     * @return virusScanResult
     */
    public java.lang.String getVirusScanResult() {
        return virusScanResult;
    }


    /**
     * Sets the virusScanResult value for this AccountItem.
     * 
     * @param virusScanResult
     */
    public void setVirusScanResult(java.lang.String virusScanResult) {
        this.virusScanResult = virusScanResult;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AccountItem)) return false;
        AccountItem other = (AccountItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.date==null && other.getDate()==null) || 
             (this.date!=null &&
              this.date.equals(other.getDate()))) &&
            this.directory == other.isDirectory() &&
            this.downloadCount == other.getDownloadCount() &&
            ((this.downloadLink==null && other.getDownloadLink()==null) || 
             (this.downloadLink!=null &&
              this.downloadLink.equals(other.getDownloadLink()))) &&
            this.empty == other.isEmpty() &&
            this.id == other.getId() &&
            this.incomplete == other.isIncomplete() &&
            ((this.md5==null && other.getMd5()==null) || 
             (this.md5!=null &&
              this.md5.equals(other.getMd5()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            this.parentId == other.getParentId() &&
            this.removed == other.isRemoved() &&
            this.shared == other.isShared() &&
            this.size == other.getSize() &&
            ((this.smallImageLink==null && other.getSmallImageLink()==null) || 
             (this.smallImageLink!=null &&
              this.smallImageLink.equals(other.getSmallImageLink()))) &&
            this.version == other.getVersion() &&
            ((this.virusScanResult==null && other.getVirusScanResult()==null) || 
             (this.virusScanResult!=null &&
              this.virusScanResult.equals(other.getVirusScanResult())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDate() != null) {
            _hashCode += getDate().hashCode();
        }
        _hashCode += (isDirectory() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getDownloadCount();
        if (getDownloadLink() != null) {
            _hashCode += getDownloadLink().hashCode();
        }
        _hashCode += (isEmpty() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += new Long(getId()).hashCode();
        _hashCode += (isIncomplete() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMd5() != null) {
            _hashCode += getMd5().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        _hashCode += new Long(getParentId()).hashCode();
        _hashCode += (isRemoved() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isShared() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += new Long(getSize()).hashCode();
        if (getSmallImageLink() != null) {
            _hashCode += getSmallImageLink().hashCode();
        }
        _hashCode += getVersion();
        if (getVirusScanResult() != null) {
            _hashCode += getVirusScanResult().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AccountItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "accountItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("directory");
        elemField.setXmlName(new javax.xml.namespace.QName("", "directory"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("downloadCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "downloadCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("downloadLink");
        elemField.setXmlName(new javax.xml.namespace.QName("", "downloadLink"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("empty");
        elemField.setXmlName(new javax.xml.namespace.QName("", "empty"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("incomplete");
        elemField.setXmlName(new javax.xml.namespace.QName("", "incomplete"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("md5");
        elemField.setXmlName(new javax.xml.namespace.QName("", "md5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "parentId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("removed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "removed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shared");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shared"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("size");
        elemField.setXmlName(new javax.xml.namespace.QName("", "size"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("smallImageLink");
        elemField.setXmlName(new javax.xml.namespace.QName("", "smallImageLink"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("virusScanResult");
        elemField.setXmlName(new javax.xml.namespace.QName("", "virusScanResult"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
