/**
 * NotificationsStatusResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class NotificationsStatusResponse  implements java.io.Serializable {
    private int _new;

    private int seen;

    private int read;

    public NotificationsStatusResponse() {
    }

    public NotificationsStatusResponse(
           int _new,
           int seen,
           int read) {
           this._new = _new;
           this.seen = seen;
           this.read = read;
    }


    /**
     * Gets the _new value for this NotificationsStatusResponse.
     * 
     * @return _new
     */
    public int get_new() {
        return _new;
    }


    /**
     * Sets the _new value for this NotificationsStatusResponse.
     * 
     * @param _new
     */
    public void set_new(int _new) {
        this._new = _new;
    }


    /**
     * Gets the seen value for this NotificationsStatusResponse.
     * 
     * @return seen
     */
    public int getSeen() {
        return seen;
    }


    /**
     * Sets the seen value for this NotificationsStatusResponse.
     * 
     * @param seen
     */
    public void setSeen(int seen) {
        this.seen = seen;
    }


    /**
     * Gets the read value for this NotificationsStatusResponse.
     * 
     * @return read
     */
    public int getRead() {
        return read;
    }


    /**
     * Sets the read value for this NotificationsStatusResponse.
     * 
     * @param read
     */
    public void setRead(int read) {
        this.read = read;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NotificationsStatusResponse)) return false;
        NotificationsStatusResponse other = (NotificationsStatusResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this._new == other.get_new() &&
            this.seen == other.getSeen() &&
            this.read == other.getRead();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += get_new();
        _hashCode += getSeen();
        _hashCode += getRead();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NotificationsStatusResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "notificationsStatusResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("_new");
        elemField.setXmlName(new javax.xml.namespace.QName("", "new"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("seen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "seen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("read");
        elemField.setXmlName(new javax.xml.namespace.QName("", "read"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
