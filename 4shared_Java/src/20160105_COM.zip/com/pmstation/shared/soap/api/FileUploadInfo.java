/**
 * FileUploadInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.pmstation.shared.soap.api;

public class FileUploadInfo  implements java.io.Serializable {
    private long fileId;

    private long freeSpace;

    private long maxFileSize;

    private java.lang.String message;

    private java.lang.String uploadUrl;

    public FileUploadInfo() {
    }

    public FileUploadInfo(
           long fileId,
           long freeSpace,
           long maxFileSize,
           java.lang.String message,
           java.lang.String uploadUrl) {
           this.fileId = fileId;
           this.freeSpace = freeSpace;
           this.maxFileSize = maxFileSize;
           this.message = message;
           this.uploadUrl = uploadUrl;
    }


    /**
     * Gets the fileId value for this FileUploadInfo.
     * 
     * @return fileId
     */
    public long getFileId() {
        return fileId;
    }


    /**
     * Sets the fileId value for this FileUploadInfo.
     * 
     * @param fileId
     */
    public void setFileId(long fileId) {
        this.fileId = fileId;
    }


    /**
     * Gets the freeSpace value for this FileUploadInfo.
     * 
     * @return freeSpace
     */
    public long getFreeSpace() {
        return freeSpace;
    }


    /**
     * Sets the freeSpace value for this FileUploadInfo.
     * 
     * @param freeSpace
     */
    public void setFreeSpace(long freeSpace) {
        this.freeSpace = freeSpace;
    }


    /**
     * Gets the maxFileSize value for this FileUploadInfo.
     * 
     * @return maxFileSize
     */
    public long getMaxFileSize() {
        return maxFileSize;
    }


    /**
     * Sets the maxFileSize value for this FileUploadInfo.
     * 
     * @param maxFileSize
     */
    public void setMaxFileSize(long maxFileSize) {
        this.maxFileSize = maxFileSize;
    }


    /**
     * Gets the message value for this FileUploadInfo.
     * 
     * @return message
     */
    public java.lang.String getMessage() {
        return message;
    }


    /**
     * Sets the message value for this FileUploadInfo.
     * 
     * @param message
     */
    public void setMessage(java.lang.String message) {
        this.message = message;
    }


    /**
     * Gets the uploadUrl value for this FileUploadInfo.
     * 
     * @return uploadUrl
     */
    public java.lang.String getUploadUrl() {
        return uploadUrl;
    }


    /**
     * Sets the uploadUrl value for this FileUploadInfo.
     * 
     * @param uploadUrl
     */
    public void setUploadUrl(java.lang.String uploadUrl) {
        this.uploadUrl = uploadUrl;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FileUploadInfo)) return false;
        FileUploadInfo other = (FileUploadInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.fileId == other.getFileId() &&
            this.freeSpace == other.getFreeSpace() &&
            this.maxFileSize == other.getMaxFileSize() &&
            ((this.message==null && other.getMessage()==null) || 
             (this.message!=null &&
              this.message.equals(other.getMessage()))) &&
            ((this.uploadUrl==null && other.getUploadUrl()==null) || 
             (this.uploadUrl!=null &&
              this.uploadUrl.equals(other.getUploadUrl())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getFileId()).hashCode();
        _hashCode += new Long(getFreeSpace()).hashCode();
        _hashCode += new Long(getMaxFileSize()).hashCode();
        if (getMessage() != null) {
            _hashCode += getMessage().hashCode();
        }
        if (getUploadUrl() != null) {
            _hashCode += getUploadUrl().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FileUploadInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://api.soap.shared.pmstation.com/", "fileUploadInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fileId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("freeSpace");
        elemField.setXmlName(new javax.xml.namespace.QName("", "freeSpace"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxFileSize");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maxFileSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("message");
        elemField.setXmlName(new javax.xml.namespace.QName("", "message"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uploadUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "uploadUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
